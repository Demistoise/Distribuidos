package practica1.controller;


import java.util.List;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import practica1.model.Comunidad;
import practica1.model.Propiedad;
import practica1.repository.ComunidadRepository;
import practica1.repository.PropiedadRepository;

@Controller
public class PropiedadController {
	@Autowired
	private ComunidadRepository repCom;
	
	@Autowired
	private PropiedadRepository repPro;
	
	
	
	@PostConstruct 		//Mete datos en la tabla
	public void init(){
		Comunidad com = new Comunidad ("H98765432",28921,"ALCORCON",789456123,"LAS ESPINAS",3);
		Comunidad com2 = new Comunidad ("H12345678",28921,"ALCORCON",759556123,"LAS ESPINAS",7);
		Comunidad com3 = new Comunidad ("H75315984",22921,"MOSTOLES",779756123,"LAS ESPINAS",9);
		
		repCom.save(com);
		repCom.save(com2);
		repCom.save(com3);
		
		Propiedad pro1 = new Propiedad ("Pepe","Perez","78945612K","LAS ESPINAS 3",987654321,"H98765432",3,5,"A",5,56478912);
		Propiedad pro2 = new Propiedad ("Nacho","Serrano","32165478L","LAS FAROLAS 6",564213589,"H98765432",2,5,"B",7,56845712);
		Propiedad pro3 = new Propiedad ("Jose","Martin","15975364J","LAS ROSALES 7",123547864,"H75315984",4,3,"B",4,56457891);
		
		repPro.save(pro1);
		repPro.save(pro2);
		repPro.save(pro3);
		
		
	}

	@RequestMapping("/") 	//Primera accion de la pagina
	public String principal (Model model){
		
		model.addAttribute("comunidad", repCom.findAll());
		model.addAttribute("propiedad", repPro.findAll());
		
		return "index";
	}
	
	@RequestMapping("/insertarPropiedad")		//Insertar propiedad. Primero se comprueba si existe
	public String insertarPropiedad (Propiedad pro, @RequestParam (value="opcion") String cif, Model model){
		List <Propiedad> p = repPro.findAll();
		boolean existepro = false;
		boolean existeper = false;
		
		if (!(pro.getNombre().equals("")) && (!(pro.getApellidos().equals(""))) && (!(pro.getDni().equals(""))) && (!(pro.getDireccion().equals(""))) && (pro.getTelefono()!=0) && (pro.getPortal()!=0) && (pro.getPlanta()!=0) && (!(pro.getLetra().equals(""))) && (pro.getPorcentaje()!=0) && (pro.getNumcuentabancaria()!=0) ){
			int i = 0;
			while (i < p.size()){
				if(p.get(i).getPertenecea().equals(cif) && (p.get(i).getPlanta()==pro.getPlanta()) && (p.get(i).getLetra().equals(pro.getLetra())) && (p.get(i).getPortal()==pro.getPortal())){
					existepro = true;
				}
				if (p.get(i).getDni().equals(pro.getDni()) && ((!(p.get(i).getNombre().equals(pro.getNombre()))) || (!(p.get(i).getApellidos().equals(pro.getApellidos()))))){
					existeper = true;
				}
				i++;
			}
			if(!existepro && !existeper){
				pro.setPertenecea(cif);
				repPro.save(pro);
				model.addAttribute("comunidad", repCom.findAll());
				model.addAttribute("propiedad", repPro.findAll());
		
			return "index";
			}
			else if (existeper){
				return "errorper";
			}
			else{
				return "errorpro";
			}
		}
		else{
			
			return "error";
		}
	}
	
	@RequestMapping("/anadirpro")		//Primer paso para añadir comunidad
	public String anadirPropiedad (Model model){
		model.addAttribute("comunidad", repCom.findAll());
		return "anadirpropiedad";
	}
	
	@RequestMapping("/consultarpropiedad")		//Muestra consulta de propiedades
	public String consulta (Model model){
		model.addAttribute("comunidad", repCom.findAll());
		return "consultarpropiedad";
	}
	
	@RequestMapping("/busquedaportal")		//Muestra propiedades por portal
	public String realizarConsultaPortal (@RequestParam (value="por") int por, Model model){
		List <Propiedad> bus = repPro.findByPortal(por);
		model.addAttribute("portal", bus);
		
		return "consultarpropiedad";
	}
	
	@RequestMapping("/busquedaportalplanta")		//Muestra propiedades por planta
	public String realizarConsultaPortalPlanta (@RequestParam (value="por2") int por,@RequestParam (value="planta") int planta, Model model){
		List <Propiedad> bus = repPro.findByPortalAndPlanta(por,planta);
		model.addAttribute("portal", bus);
		
		return "consultarpropiedad";
	}
	
	@RequestMapping("/busquedaapellidos")		//Muestra propiedades por apellidos
	public String realizarConsultaApellidos (@RequestParam (value="apellidos") String apellidos,Model model){
		List <Propiedad> bus = repPro.findByApellidos(apellidos);
		model.addAttribute("portal", bus);
		
		return "consultarpropiedad";
	}
	
	@RequestMapping("/busquedadni")		//Muestra propiedades por dni
	public String realizarConsultaDni (@RequestParam (value="dni") String dni, Model model){
		List <Propiedad> bus = repPro.findByDni(dni);
		model.addAttribute("portal", bus);
		
		return "consultarpropiedad";
	}
	
	@RequestMapping("/busquedapertenece")		//Muestra propiedades por comunidad a la que pertenece
	public String realizarConsultaPertenece (@RequestParam (value="opcion") String cif, Model model){
		List <Propiedad> bus = repPro.findByPertenecea(cif);
		model.addAttribute("portal", bus);
		model.addAttribute("comunidad",repCom.findAll());
		
		return "consultarpropiedad";
		
	}
	
	@RequestMapping("/eliminarpropiedad")		//Primer paso para eliminar propiedad
	public String eliminar (Model model){
		model.addAttribute("propiedad", repPro.findAll());
		return "eliminarpropiedad";
	}
	
	@RequestMapping("/confirmareliminacionpropiedad")		//Segundo paso para eliminar propiedad
	public String confirmareliminar (@RequestParam (value="opcion") int id, Model model){
		List <Propiedad> p = repPro.findById(id);
		repPro.delete(p);
		
		model.addAttribute("comunidad", repCom.findAll());
		model.addAttribute("propiedad", repPro.findAll());
		return "/index";
	}
	
	@RequestMapping("/modificarpropiedad")		//Primer paso para modificar propiedad
	public String modificar (Model model){
		model.addAttribute("propiedad", repPro.findAll());
		model.addAttribute("comunidad", repCom.findAll());
		return "modificarpropiedad";
	}
	
	@RequestMapping("/confirmarmodificacionpropiedad")		//Segundo paso para modificar propiedad
	public String confirmarModificar (@RequestParam (value="opcion") int id,@RequestParam (value="nombre") String nombre,@RequestParam (value="apellidos") String apellidos,@RequestParam (value="dni") String dni,@RequestParam (value="direccion") String direccion,@RequestParam (value="telefono") long telefono,@RequestParam (value="opcion2") String cif,@RequestParam (value="portal") int portal,@RequestParam (value="planta") int planta,@RequestParam (value="letra") String letra,@RequestParam (value="porcentaje") double porcentaje,@RequestParam (value="cuenta") long cuenta, Model model){
		List <Propiedad> p = repPro.findById(id);
		for(int i=0; i < p.size(); i++){
			if (!(nombre.equals(""))){
				p.get(i).setNombre(nombre);
			}
			if (!(apellidos.equals(""))){
				p.get(i).setApellidos(apellidos);
			}
			if (!(dni.equals(""))){
				p.get(i).setDni(dni);
			}
			if (!(direccion.equals(""))){
				p.get(i).setDireccion(direccion);
			}
			if (telefono!=0){
				p.get(i).setTelefono(telefono);
			}
			if (!(cif.equals(""))){
				p.get(i).setPertenecea(cif);
			}
			if (portal!=0){
				p.get(i).setPortal(portal);
			}
			if (planta!=0){
				p.get(i).setPlanta(planta);
			}
			if (!(letra.equals(""))){
				p.get(i).setLetra(letra);
			}
			if (porcentaje!=0){
				p.get(i).setPorcentaje(porcentaje);
			}
			if (cuenta!=0){
				p.get(i).setNumcuentabancaria(cuenta);
			}
		}
		
		repPro.flush();
		model.addAttribute("comunidad", repCom.findAll());
		model.addAttribute("propiedad", repPro.findAll());
		return "index";
		
		
	}
	
	
	
	
	
	
}
