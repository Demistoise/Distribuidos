# Distribuidos

Diego Forte Jara <p>
Sergio Lázaro Matesanz <p>
Victor Manuel Martínez Severiano <p>
Asier Ruano Peñas <p>
<p> <p>
Material necesario https://spring.io/tools <p>
Tutorial Spring STS http://www.uv.es/grimo/teaching/SpringMVCv3PasoAPaso/part1.html <p>
Tutorial BDD H2 http://albertovilches.com/tutorial-h2-database



