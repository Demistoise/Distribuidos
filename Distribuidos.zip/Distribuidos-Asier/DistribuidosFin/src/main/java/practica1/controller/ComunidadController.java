package practica1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import practica1.model.Comunidad;
import practica1.model.Propiedad;
import practica1.repository.ComunidadRepository;
import practica1.repository.PropiedadRepository;

@Controller
public class ComunidadController {
	@Autowired
	private ComunidadRepository repCom;
	
	@Autowired
	private PropiedadRepository repPro;
	
	
	@RequestMapping("/anadircom")
	public String anadirCom (){
		
		return "anadircomunidad";
	}
	
	@RequestMapping("/insertarComunidad")	// Insertar comunidad. Antes de insertar, comprueba si existe
	public String insertarComunidad (Comunidad com, Model model){
		boolean existe= false;
		List <Comunidad> p = repCom.findAll();
		if (!(com.getCif().equals("")) && (com.getCodigopostal()!=0) && (!(com.getPoblacion().equals(""))) && (com.getCuentabancaria()!=0) && (!(com.getCalle().equals(""))) && (com.getNumero()!=0)){
			int i = 0;
			while(i < p.size()){
				if((p.get(i).getCif().equals(com.getCif()))){
					existe = true;
				}
				if (p.get(i).getCuentabancaria()==com.getCuentabancaria()){
					existe = true;
				}
				if (p.get(i).getCalle().equals(com.getCalle()) && (p.get(i).getNumero()==com.getNumero())){
					existe = true;
				}
				i++;
			}		
			if (!existe){
				repCom.save(com);
				model.addAttribute("comunidad", repCom.findAll());
				model.addAttribute("propiedad", repPro.findAll());
					
				return "index";
			}
			else{
				return "errorcom";
			}
			}
				else{
					return "error";
				}
			
		}

		
	
	
	@RequestMapping("/consultarcomunidad")		//Muestra comunidades y propiedades por consulta
	public String consultarComunidad (Model model){
		
		model.addAttribute("comunidad", repCom.findAll());
		model.addAttribute("propiedad", repPro.findAll());
		
		return "consultarcomunidad";
	}
	
	@RequestMapping("/busquedacif")				//Muestra comunidades por cif
	public String busquedaCif (@RequestParam (value="opcion") String cif,Model model){
		
		
		model.addAttribute("portal", repCom.findByCif(cif));
		model.addAttribute("comunidad", repCom.findAll());
		
		return "consultarcomunidad";
	}
	
	@RequestMapping("/busquedacp")			//Muestra comunidades por codigo postal
	public String busquedaCp (@RequestParam (value="cp") int cp,Model model){
		
		
		model.addAttribute("portal", repCom.findByCodigopostal(cp));
		model.addAttribute("comunidad", repCom.findAll());
		
		return "consultarcomunidad";
	}
	
	@RequestMapping("/busquedapoblacion")		//Muestra comunidades por poblacion
	public String busquedaPoblacion (@RequestParam (value="poblacion") String poblacion,Model model){
		
		
		model.addAttribute("portal", repCom.findByPoblacion(poblacion));
		model.addAttribute("comunidad", repCom.findAll());
		
		return "consultarcomunidad";
	}
	
	@RequestMapping("/busquedacuenta")			//Muestra comunidades por numero de cuenta
	public String busquedaCuenta (@RequestParam (value="cuenta") long cuenta,Model model){
		
		
		model.addAttribute("portal", repCom.findByCuentabancaria(cuenta));
		model.addAttribute("comunidad", repCom.findAll());
		
		return "consultarcomunidad";
	}
	
	@RequestMapping("/busquedacalle")			//Muestra comunidades por calle
	public String busquedaCalle (@RequestParam (value="calle") String calle,Model model){
		
		
		model.addAttribute("portal", repCom.findByCalle(calle));
		model.addAttribute("comunidad", repCom.findAll());
		
		return "consultarcomunidad";
	}
	
	@RequestMapping("/busquedanumero")		//Muestra comunidades por numero
	public String busquedaNumero (@RequestParam (value="numero") int numero,Model model){
		
		
		model.addAttribute("portal", repCom.findByNumero(numero));
		model.addAttribute("comunidad", repCom.findAll());
		
		return "consultarcomunidad";
	}
	
	@RequestMapping("/eliminarcomunidad")	//Primero paso para eliminar comunidad
	public String eliminar (Model model){
		model.addAttribute("comunidad", repCom.findAll());
		return "eliminarcomunidad";
	}
	
	@RequestMapping("/confirmareliminacioncomunidad")	//Segundo paso para eliminar comunidad
	public String confirmareliminar (@RequestParam (value="opcion") String cif, Model model){
		List <Propiedad> pro = repPro.findByPertenecea(cif);
		repPro.delete(pro);
		List <Comunidad> com = repCom.findByCif(cif);
		repCom.delete(com);
		
		model.addAttribute("comunidad", repCom.findAll());
		model.addAttribute("propiedad", repPro.findAll());
		return "/index";
	}
	
	@RequestMapping("/modificarcomunidad")	//Primer paso para modificar comunidades
	public String modificar (Model model){
		model.addAttribute("comunidad", repCom.findAll());
		return "modificarcomunidad";
	}
	
	@RequestMapping("/confirmarmodificacioncomunidad")		//Segundo paso para modificar comunidades
	public String confirmarModificar (@RequestParam (value="opcion") String cif,@RequestParam (value="cp") int cp,@RequestParam (value="poblacion") String poblacion,@RequestParam (value="cuenta") long cuenta,@RequestParam (value="calle") String calle,@RequestParam (value="numero") int numero, Model model){
		Comunidad com = repCom.findOne(cif);
		if (cp!=0){
			com.setCodigopostal(cp);
		}
		if (!(poblacion.equals(""))){
			com.setPoblacion(poblacion);
		}
		if (cuenta!=0){
			com.setCuentabancaria(cuenta);
		}
		if (!(calle.equals(""))){
			com.setCalle(calle);
		}
		if (numero!=0){
			com.setNumero(numero);
		}
		
		repCom.flush();

		
		model.addAttribute("comunidad", repCom.findAll());
		model.addAttribute("propiedad", repPro.findAll());
		return "/index";
	}
		
	@RequestMapping("/volver")		//Volver a pagina principal
	public String volver(Model model){
		model.addAttribute("comunidad", repCom.findAll());
		model.addAttribute("propiedad", repPro.findAll());
		return "index";
	}
}
